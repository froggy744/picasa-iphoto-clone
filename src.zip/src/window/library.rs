use std::sync::mpsc::TryRecvError;

static REFRESH_GENERATION: std::sync::atomic::AtomicU64 =
    std::sync::atomic::AtomicU64::new(0);
static SHARE_READY_GENERATION: std::sync::atomic::AtomicU64 =
    std::sync::atomic::AtomicU64::new(0);

/// Invalidate any asynchronous grid result or delayed folder destination from
/// an older navigation. Folder-to-folder reuse does not start a new database
/// refresh, so it must still advance this generation to prevent an older
/// Albums/Photos -> Folder timer from pulling the view back later.
fn invalidate_pending_grid_navigation() {
    REFRESH_GENERATION.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
}

fn refresh_grid(
    connection: &Rc<RefCell<Connection>>,
    filter: sidebar::SidebarFilter,
    search: &str,
    sort: PhotoSort,
    gallery: &Rc<grid::Gallery>,
) {
    let folder_target = if search.is_empty() {
        if let sidebar::SidebarFilter::Folder(folder_id) = filter {
            db::folders_light(&connection.borrow())
                .ok()
                .and_then(|folders| folders.into_iter().find(|folder| folder.id == folder_id))
                .map(|folder| (folder.id, folder.path))
        } else {
            None
        }
    } else {
        None
    };
    refresh_grid_inner(connection, filter, search, sort, gallery, folder_target, false);
}

fn refresh_grid_to_folder(
    connection: &Rc<RefCell<Connection>>,
    filter: sidebar::SidebarFilter,
    search: &str,
    sort: PhotoSort,
    gallery: &Rc<grid::Gallery>,
    folder_id: i64,
    folder_path: String,
) {
    refresh_grid_inner(
        connection,
        filter,
        search,
        sort,
        gallery,
        Some((folder_id, folder_path)),
        false,
    );
}

/// Results delivered from the off-thread grid query.
///
/// Folder destinations send two payloads: an interim `Scoped` snapshot of the
/// selected folder so the grid is populated the instant it lands, then the
/// `Stream` spanning the whole continuous Folder stream which is built in the
/// background and swapped in once ready. Every other destination sends only
/// the `Stream`.
// An existing library can contain photos indexed through the gvfs FUSE mount
// while a registered share is stored as smb://host/share/subfolder. Those
// references describe the same files, but are separate folder trees in SQLite.
// Compare them without touching the network or creating GTK photo objects.
fn share_location(reference: &str) -> Option<(String, String)> {
    // Decode URI path escapes (not '+' which is a literal filename character).
    fn unescape(value: &str) -> String {
        let bytes = value.as_bytes();
        let mut out = Vec::with_capacity(bytes.len());
        let mut i = 0;
        while i < bytes.len() {
            if bytes[i] == b'%' && i + 2 < bytes.len() {
                let hex = |c: u8| -> Option<u8> {
                    match c {
                        b'0'..=b'9' => Some(c - b'0'),
                        b'a'..=b'f' => Some(c - b'a' + 10),
                        b'A'..=b'F' => Some(c - b'A' + 10),
                        _ => None,
                    }
                };
                if let (Some(hi), Some(lo)) = (hex(bytes[i + 1]), hex(bytes[i + 2])) {
                    out.push(hi * 16 + lo);
                    i += 3;
                    continue;
                }
            }
            out.push(bytes[i]);
            i += 1;
        }
        String::from_utf8_lossy(&out).into_owned()
    }

    let lower = reference.to_ascii_lowercase();
    if let Some(rest) = lower.strip_prefix("smb://") {
        let (host, path) = rest.split_once('/').unwrap_or((rest, ""));
        let host = host.rsplit('@').next()?.split(':').next()?;
        if host.is_empty() { return None; }
        return Some((host.to_owned(), unescape(path).trim_matches('/').to_owned()));
    }
    // gvfs mounts use /run/user/UID/gvfs/smb-share:server=HOST,share=SHARE/path.
    // Only accept an actual gvfs mount prefix, not arbitrary local filenames.
    let (_, mount) = lower.split_once("/gvfs/smb-share:server=")?;
    let (host_part, share_part) = mount.split_once(",share=")?;
    let host = host_part.split(',').next()?.split(':').next()?;
    if host.is_empty() { return None; }
    let path = share_part.split(',').next().unwrap_or(share_part);
    Some((host.to_owned(), unescape(path).trim_matches('/').to_owned()))
}

pub(crate) fn path_belongs_to_share(share: &str, candidate: &str) -> bool {
    let (share_host, share_path) = match share_location(share) {
        Some(location) => location,
        None => return false,
    };
    let (candidate_host, candidate_path) = match share_location(candidate) {
        Some(location) => location,
        None => return false,
    };
    share_host == candidate_host
        && (share_path.is_empty()
            || candidate_path == share_path
            || candidate_path.starts_with(&(share_path + "/")))
}

enum GridPayload {
    Scoped(Vec<db::Photo>),
    Share(Vec<db::Photo>),
    Stream(Vec<db::Photo>),
    Failed,
}

fn refresh_grid_inner(
    connection: &Rc<RefCell<Connection>>,
    filter: sidebar::SidebarFilter,
    search: &str,
    sort: PhotoSort,
    gallery: &Rc<grid::Gallery>,
    folder_target: Option<(i64, String)>,
    exact_local_folder: bool,
) {
    let _ = connection;
    if filter == sidebar::SidebarFilter::Albums {
        return;
    }
    let generation = REFRESH_GENERATION.fetch_add(1, std::sync::atomic::Ordering::Relaxed) + 1;
    let op = crate::source::current_trace_op();
    let search = search.to_owned();
    let folder_stream = !exact_local_folder && search.is_empty()
        && matches!(filter, sidebar::SidebarFilter::Folder(_));
    let (sender, receiver) = std::sync::mpsc::channel();
    let scoped_target = folder_target.clone();
    // A network-share sidebar selection is a bounded library destination, not
    // a request to materialize the entire 70k+ photo Folder stream.
    let share_target = folder_target.as_ref().and_then(|(id, path)| {
        crate::source::is_network_location(path).then_some((*id, path.clone()))
    });

    std::thread::spawn(move || {
        crate::source::net_trace(format!(
            "grid_query_start op={op} filter={filter:?} folder_stream={folder_stream}"
        ));
        let connection = match db::open_default_read_only() {
            Ok(connection) => connection,
            Err(error) => {
                crate::source::net_trace(format!("grid_failed op={op} error={error:#}"));
                let _ = sender.send(GridPayload::Failed);
                return;
            }
        };

        if let Some((share_id, share_path)) = share_target {
            // Keep descendants from the real folder tree AND photos imported
            // earlier via a gvfs mount / URI spelling. Do all database work in
            // this worker: only the bounded share result reaches GTK.
            let indexed = match db::photos(&connection, Some(share_id), false, None) {
                Ok(photos) => photos,
                Err(error) => {
                    crate::source::net_trace(format!("grid_share_query_failed op={op} error={error}"));
                    let _ = sender.send(GridPayload::Failed);
                    return;
                }
            };
            let descendant_ids: std::collections::HashSet<i64> =
                indexed.iter().map(|photo| photo.id).collect();
            let all = match db::photos(&connection, None, false, None) {
                Ok(photos) => photos,
                Err(error) => {
                    crate::source::net_trace(format!("grid_share_query_failed op={op} error={error}"));
                    let _ = sender.send(GridPayload::Failed);
                    return;
                }
            };
            let mut photos: Vec<db::Photo> = all.into_iter().filter(|photo| {
                descendant_ids.contains(&photo.id)
                    || path_belongs_to_share(&share_path, &photo.path)
                    || photo.folder_path.as_deref().is_some_and(|path| {
                        path_belongs_to_share(&share_path, path)
                    })
            }).collect();
            crate::source::net_trace(format!(
                "grid_share_matched op={op} root={} descendants={} matched={}",
                share_path, descendant_ids.len(), photos.len()
            ));
            retain_enabled_formats(&connection, &mut photos);
            let folders = db::folders_light(&connection).unwrap_or_default();
            let display_mode = sidebar::FolderDisplayMode::from_setting(
                db::setting(&connection, sidebar::FOLDER_DISPLAY_MODE_SETTING_KEY)
                    .ok().flatten().as_deref(),
            );
            sort_folder_stream(&mut photos, &folders, sort, display_mode);
            crate::source::net_trace(format!(
                "grid_share_scoped op={op} count={}", photos.len()
            ));
            let _ = sender.send(GridPayload::Share(photos));
            return;
        }

        if exact_local_folder {
            // Open in Folder is an exact photo destination, not a request to
            // construct the 73k-photo continuous folder browser. Reuse the
            // complete scoped payload path already used by Network Shares.
            let Some((folder_id, _)) = scoped_target else {
                let _ = sender.send(GridPayload::Failed);
                return;
            };
            let mut photos = match db::photos(&connection, Some(folder_id), false, None) {
                Ok(photos) => photos,
                Err(error) => {
                    crate::source::net_trace(format!("grid_local_exact_failed op={op} error={error}"));
                    let _ = sender.send(GridPayload::Failed);
                    return;
                }
            };
            retain_enabled_formats(&connection, &mut photos);
            let folders = db::folders_light(&connection).unwrap_or_default();
            let display_mode = sidebar::FolderDisplayMode::from_setting(
                db::setting(&connection, sidebar::FOLDER_DISPLAY_MODE_SETTING_KEY)
                    .ok().flatten().as_deref(),
            );
            sort_folder_stream(&mut photos, &folders, sort, display_mode);
            crate::source::net_trace(format!("grid_local_exact_scoped op={op} folder={folder_id} count={}", photos.len()));
            let _ = sender.send(GridPayload::Share(photos));
            return;
        }

        if folder_stream {
            // Picasa-style Folder mode shows the selected folder's subtree.
            // With a concrete folder target the scoped payload below IS the
            // destination; only target-less Folder refreshes (and All
            // Photos/searches via the branches below) build a whole-library
            // view.
            //
            // Folder ordering for the stream sort uses the probe-free listing:
            // availability is resolved separately and asynchronously by the
            // availability refresher. An unmounted remote root would otherwise
            // stall this worker for seconds before the scoped snapshot could
            // be sent.
            let stream_folders = db::folders_light(&connection).unwrap_or_default();
            let display_mode = sidebar::FolderDisplayMode::from_setting(
                db::setting(&connection, sidebar::FOLDER_DISPLAY_MODE_SETTING_KEY)
                    .ok()
                    .flatten()
                    .as_deref(),
            );
            // Fedora regression (v15): selecting a folder must not build the
            // whole-library continuous stream (62k scoped + 73k stream for
            // one click, with multi-hundred-ms main-thread stalls). A folder
            // with a concrete target now shows exactly that folder's subtree;
            // the full-library stream remains available via All Photos and
            // searches, which take the branches below.
            if let Some((folder_id, _)) = scoped_target {
                let mut scoped = db::photos(&connection, Some(folder_id), false, None)
                    .unwrap_or_default();
                retain_enabled_formats(&connection, &mut scoped);
                sort_folder_stream(&mut scoped, &stream_folders, sort, display_mode);
                crate::source::net_trace(format!("grid_scoped op={op} count={}", scoped.len()));
                let _ = sender.send(GridPayload::Share(scoped));
                return;
            }

            let mut stream = db::photos(&connection, None, false, None).unwrap_or_default();
            retain_enabled_formats(&connection, &mut stream);
            sort_folder_stream(&mut stream, &stream_folders, sort, display_mode);
            crate::source::net_trace(format!("grid_stream op={op} count={}", stream.len()));
            let _ = sender.send(GridPayload::Stream(stream));
            return;
        }

        let mut photos = if !search.is_empty() {
            // An active search is a library-wide view, regardless of the
            // destination that was selected before typing began.
            db::photos(&connection, None, false, Some(&search)).unwrap_or_default()
        } else if let sidebar::SidebarFilter::Album(album_id) = filter {
            db::photos_in_album(&connection, album_id, None).unwrap_or_default()
        } else {
            let (folder_id, favorites) = match filter {
                sidebar::SidebarFilter::All | sidebar::SidebarFilter::RecentlyAdded => {
                    (None, false)
                }
                sidebar::SidebarFilter::Favorites => (None, true),
                sidebar::SidebarFilter::Folder(_) => (None, false),
                sidebar::SidebarFilter::Albums => return,
                sidebar::SidebarFilter::Album(_) => unreachable!(),
            };
            db::photos(&connection, folder_id, favorites, None).unwrap_or_default()
        };

        retain_enabled_formats(&connection, &mut photos);
        limit_recently_added(&connection, filter, &mut photos);
        sort_photos(&mut photos, sort);
        crate::source::net_trace(format!("grid_stream op={op} count={}", photos.len()));
        let _ = sender.send(GridPayload::Stream(photos));
    });

    let gallery = gallery.clone();
    glib::timeout_add_local(std::time::Duration::from_millis(25), move || {
        match receiver.try_recv() {
            Ok(GridPayload::Share(photos)) => {
                if REFRESH_GENERATION.load(std::sync::atomic::Ordering::Relaxed) == generation {
                    crate::source::net_trace(format!(
                        "grid_share_replace op={op} count={}", photos.len()
                    ));
                    gallery.invalidate_folder_cache();
                    // The share snapshot is the COMPLETE requested view; do not
                    // prewarm/swap in a library-wide stream behind it.
                    gallery.replace_scoped_folder(&photos);
                    SHARE_READY_GENERATION.store(generation, std::sync::atomic::Ordering::Relaxed);
                    crate::source::net_trace(format!("grid_share_ready op={op}"));
                }
                crate::source::clear_trace_op_after(op);
                glib::ControlFlow::Break
            }
            Ok(GridPayload::Scoped(photos)) => {
                if REFRESH_GENERATION.load(std::sync::atomic::Ordering::Relaxed) == generation {
                    crate::source::net_trace(format!(
                        "grid_payload_scoped op={op} count={}",
                        photos.len()
                    ));
                    // Show the destination folder immediately. Unlike replace(),
                    // this never caches the snapshot as the full Folder stream.
                    gallery.replace_scoped_folder(&photos);
                }
                crate::source::clear_trace_op_after(op);
                glib::ControlFlow::Continue
            }
            Ok(GridPayload::Stream(photos)) => {
                if REFRESH_GENERATION.load(std::sync::atomic::Ordering::Relaxed) == generation {
                    if folder_stream {
                        crate::source::net_trace(format!(
                            "gallery_prewarm op={op} count={}",
                            photos.len()
                        ));
                        // Build the continuous stream without blanking the
                        // scoped Folder snapshot the user is looking at.
                        gallery.prewarm_folder_stream(photos);
                    } else {
                        crate::source::net_trace(format!(
                            "gallery_replace op={op} count={}",
                            photos.len()
                        ));
                        gallery.replace(&photos);
                    }
                    if let Some((folder_id, folder_path)) = folder_target.clone() {
                        let gallery = gallery.clone();
                        // prewarm() may schedule a progressive model build.
                        // Start the scroll helper on the next main-loop turn so
                        // it never succeeds against the previous grid model.
                        glib::idle_add_local_once(move || {
                            scroll_gallery_to_folder_when_ready(
                                gallery,
                                folder_id,
                                folder_path,
                                generation,
                            );
                        });
                    }
                }
                glib::ControlFlow::Break
            }
            Ok(GridPayload::Failed) | Err(TryRecvError::Disconnected) => {
                glib::ControlFlow::Break
            }
            Err(TryRecvError::Empty) => glib::ControlFlow::Continue,
        }
    });
}

/// Scroll a sidebar folder selection to its section once a potentially
/// progressive Folder-stream replacement has loaded far enough to contain it.
fn scroll_gallery_to_folder_when_ready(
    gallery: Rc<grid::Gallery>,
    folder_id: i64,
    folder_path: String,
    generation: u64,
) {
    let total_attempts = Rc::new(Cell::new(0u32));
    // Counts only the attempts made after the progressive stream finished.
    // While rows are still being built, the target folder may legitimately not
    // exist yet, so those attempts must not count toward giving up.
    let settled_attempts = Rc::new(Cell::new(0u32));
    let total_for_timer = total_attempts.clone();
    let settled_for_timer = settled_attempts.clone();
    glib::timeout_add_local(Duration::from_millis(25), move || {
        // A newer destination/refresh supersedes this timer. Without this
        // guard, an old Albums/Photos -> Folder transition can fire later and
        // pull the continuous Folder view back to the previous folder.
        if REFRESH_GENERATION.load(std::sync::atomic::Ordering::Relaxed) != generation {
            return glib::ControlFlow::Break;
        }
        total_for_timer.set(total_for_timer.get() + 1);
        // scroll_to_folder scans the whole photo model. Calling it every 25 ms
        // while the progressive Folder stream is still being built starves that
        // very build, so wait for it to finish before scanning at all. The
        // scoped snapshot shown while the stream prewarms must be skipped too:
        // it is only a scroll-destination hint, not the final continuous stream.
        if !gallery.folder_stream_ready() {
            if total_for_timer.get() >= 1200 {
                // Hard safety net (30 s) for a build that never completes.
                glib::ControlFlow::Break
            } else {
                glib::ControlFlow::Continue
            }
        } else if gallery.scroll_to_folder(folder_id, &folder_path) {
            glib::ControlFlow::Break
        } else {
            let settled = settled_for_timer.get() + 1;
            settled_for_timer.set(settled);
            if settled >= 240 {
                // Six seconds after the Folder stream is fully built is
                // generous; a missing/empty folder leaves the position as-is.
                glib::ControlFlow::Break
            } else {
                glib::ControlFlow::Continue
            }
        }
    });
}

fn limit_recently_added(
    connection: &Connection,
    filter: sidebar::SidebarFilter,
    photos: &mut Vec<db::Photo>,
) {
    if filter != sidebar::SidebarFilter::RecentlyAdded {
        return;
    }

    // Select the newest files first, then restore the user's chosen display
    // ordering in refresh_grid().
    sort_photos(
        photos,
        PhotoSort {
            field: SortField::DateAdded,
            direction: SortDirection::Descending,
        },
    );
    photos.truncate(db::recently_added_limit(connection));
}

fn retain_enabled_formats(connection: &Connection, photos: &mut Vec<db::Photo>) {
    let enabled = crate::image_format::enabled_ids(connection).unwrap_or_else(|_| {
        crate::image_format::all()
            .iter()
            .map(|format| format.id)
            .collect()
    });
    photos.retain(|photo| crate::image_format::path_is_enabled_in(&enabled, &photo.path));
}

fn sort_photos(photos: &mut [db::Photo], sort: PhotoSort) {
    photos.sort_by(|left, right| photo_ordering(left, right, sort));
}

fn photo_ordering(left: &db::Photo, right: &db::Photo, sort: PhotoSort) -> Ordering {
    let ordering = match sort.field {
        SortField::DateTaken => compare_optional(
            left.taken_at.as_deref(),
            right.taken_at.as_deref(),
            sort.direction,
        ),
        SortField::Name => directed_ordering(
            crate::source::filename(&left.path)
                .to_lowercase()
                .cmp(&crate::source::filename(&right.path).to_lowercase()),
            sort.direction,
        ),
        SortField::FileSize => compare_optional(left.size_bytes, right.size_bytes, sort.direction),
        SortField::Dimensions => compare_optional(
            pixel_count(left.width, left.height),
            pixel_count(right.width, right.height),
            sort.direction,
        ),
        SortField::DateAdded => directed_ordering(
            left.added_at
                .cmp(&right.added_at)
                .then(left.id.cmp(&right.id)),
            sort.direction,
        ),
    };

    ordering.then_with(|| left.path.to_lowercase().cmp(&right.path.to_lowercase()))
}

/// Order the Folder view as one stream of direct-folder sections. Photos are
/// sorted normally inside each section, while folder sections follow the same
/// hierarchy users see in the sidebar. Imported-only mode keeps imported roots
/// together and in the same alphabetical root order as that sidebar mode.
fn sort_folder_stream(
    photos: &mut [db::Photo],
    folders: &[db::Folder],
    sort: PhotoSort,
    display_mode: sidebar::FolderDisplayMode,
) {
    let order = folder_stream_order(folders, display_mode);
    let rank = order
        .iter()
        .enumerate()
        .map(|(index, folder_id)| (*folder_id, index))
        .collect::<std::collections::HashMap<_, _>>();
    photos.sort_by(|left, right| {
        let left_rank = rank
            .get(&left.folder_id.unwrap_or_default())
            .copied()
            .unwrap_or(usize::MAX);
        let right_rank = rank
            .get(&right.folder_id.unwrap_or_default())
            .copied()
            .unwrap_or(usize::MAX);
        left_rank
            .cmp(&right_rank)
            .then_with(|| photo_ordering(left, right, sort))
    });
}

/// Folder ids in the canonical order used by the continuous Folder gallery.
///
/// Sidebar Flat/Tree is presentation-only. The gallery must keep one stable
/// section order across that toggle; otherwise GtkListView has to splice and
/// recycle the visible row set just because the sidebar changed shape.
pub(super) fn folder_stream_order(
    folders: &[db::Folder],
    _display_mode: sidebar::FolderDisplayMode,
) -> Vec<i64> {
    folder_tree_order(folders)
}

fn folder_tree_order(folders: &[db::Folder]) -> Vec<i64> {
    let by_id = folders
        .iter()
        .map(|folder| (folder.id, folder))
        .collect::<std::collections::HashMap<_, _>>();
    let mut children = std::collections::HashMap::<Option<i64>, Vec<i64>>::new();
    for folder in folders {
        children.entry(folder.parent_id).or_default().push(folder.id);
    }
    for ids in children.values_mut() {
        ids.sort_by(|left, right| {
            let left = by_id.get(left).expect("folder id exists");
            let right = by_id.get(right).expect("folder id exists");
            left.name
                .to_lowercase()
                .cmp(&right.name.to_lowercase())
                .then_with(|| left.path.to_lowercase().cmp(&right.path.to_lowercase()))
        });
    }

    fn visit(
        folder_id: i64,
        children: &std::collections::HashMap<Option<i64>, Vec<i64>>,
        seen: &mut std::collections::HashSet<i64>,
        order: &mut Vec<i64>,
    ) {
        if !seen.insert(folder_id) {
            return;
        }
        order.push(folder_id);
        if let Some(ids) = children.get(&Some(folder_id)) {
            for child_id in ids {
                visit(*child_id, children, seen, order);
            }
        }
    }

    let mut order = Vec::with_capacity(folders.len());
    let mut seen = std::collections::HashSet::new();
    if let Some(roots) = children.get(&None) {
        for root_id in roots {
            visit(*root_id, &children, &mut seen, &mut order);
        }
    }
    // Corrupt/legacy parent links must not make a folder disappear from the
    // stream. Append any orphaned rows deterministically at the end.
    let mut remaining = folders
        .iter()
        .filter(|folder| !seen.contains(&folder.id))
        .collect::<Vec<_>>();
    remaining.sort_by(|left, right| left.path.to_lowercase().cmp(&right.path.to_lowercase()));
    for folder in remaining {
        visit(folder.id, &children, &mut seen, &mut order);
    }
    order
}

fn compare_optional<T: Ord>(
    left: Option<T>,
    right: Option<T>,
    direction: SortDirection,
) -> Ordering {
    match (left, right) {
        (Some(left), Some(right)) => directed_ordering(left.cmp(&right), direction),
        (Some(_), None) => Ordering::Less,
        (None, Some(_)) => Ordering::Greater,
        (None, None) => Ordering::Equal,
    }
}

fn directed_ordering(ordering: Ordering, direction: SortDirection) -> Ordering {
    match direction {
        SortDirection::Ascending => ordering,
        SortDirection::Descending => ordering.reverse(),
    }
}

fn pixel_count(width: Option<i64>, height: Option<i64>) -> Option<i128> {
    match (width, height) {
        (Some(width), Some(height)) if width > 0 && height > 0 => {
            Some(i128::from(width) * i128::from(height))
        }
        _ => None,
    }
}

#[cfg(test)]
mod photo_action_tests {
    use super::{
        folder_stream_order, sort_folder_stream, sort_photos, valid_file_name, wallpaper_layout,
        PhotoSort, SortDirection, SortField, WallpaperLayout,
    };
    use crate::db::{Folder, Photo};

    #[test]
    fn rename_rejects_paths_and_accepts_a_file_name() {
        assert!(valid_file_name("holiday photo.jpg"));
        assert!(!valid_file_name(""));
        assert!(!valid_file_name(".."));
        assert!(!valid_file_name("folder/photo.jpg"));
    }

    #[test]
    fn wallpaper_layout_preserves_portraits_and_panorama_width() {
        assert_eq!(
            wallpaper_layout(3000, 4500, 1920, 1080),
            WallpaperLayout::PortraitBlur
        );
        assert_eq!(
            wallpaper_layout(6000, 4000, 1920, 1080),
            WallpaperLayout::Cover
        );
        assert_eq!(
            wallpaper_layout(8000, 2000, 1920, 1080),
            WallpaperLayout::PanoramaBlur
        );
    }

    fn photo(
        path: &str,
        taken_at: Option<&str>,
        size_bytes: Option<i64>,
        dimensions: Option<(i64, i64)>,
        mtime: Option<i64>,
    ) -> Photo {
        Photo {
            id: 0,
            path: path.to_string(),
            folder_id: None,
            folder_path: None,
            taken_at: taken_at.map(str::to_string),
            camera: None,
            width: dimensions.map(|value| value.0),
            height: dimensions.map(|value| value.1),
            size_bytes,
            mtime,
            added_at: mtime.unwrap_or_default(),
            rotation: 0,
            edit_recipe: String::new(),
            favorite: false,
            trashed: false,
        }
    }

    fn folder(
        id: i64,
        path: &str,
        name: &str,
        parent_id: Option<i64>,
        imported_root: bool,
    ) -> Folder {
        Folder {
            id,
            path: path.to_string(),
            name: name.to_string(),
            parent_id,
            imported_root,
            watched: false,
            photo_count: 1,
            subfolder_count: 0,
            available: true,
        }
    }

    fn photo_in_folder(path: &str, folder_id: i64, folder_path: &str) -> Photo {
        let mut value = photo(path, Some("2024-01-01 12:00:00"), None, None, None);
        value.folder_id = Some(folder_id);
        value.folder_path = Some(folder_path.to_string());
        value
    }

    #[test]
    fn folder_stream_uses_tree_section_order_not_global_photo_sort() {
        let folders = vec![
            folder(1, "/root", "root", None, true),
            folder(2, "/root/B", "B", Some(1), false),
            folder(3, "/root/A", "A", Some(1), false),
        ];
        let mut photos = vec![
            photo_in_folder("/root/B/b.jpg", 2, "/root/B"),
            photo_in_folder("/root/A/z.jpg", 3, "/root/A"),
            photo_in_folder("/root/A/a.jpg", 3, "/root/A"),
        ];

        sort_folder_stream(
            &mut photos,
            &folders,
            PhotoSort {
                field: SortField::Name,
                direction: SortDirection::Ascending,
            },
            crate::sidebar::FolderDisplayMode::Tree,
        );

        assert_eq!(
            photos
                .iter()
                .map(|photo| (photo.folder_id, crate::source::filename(&photo.path)))
                .collect::<Vec<_>>(),
            vec![
                (Some(3), "a.jpg".to_string()),
                (Some(3), "z.jpg".to_string()),
                (Some(2), "b.jpg".to_string()),
            ]
        );
    }

    #[test]
    fn sidebar_display_mode_does_not_reorder_folder_gallery() {
        let folders = vec![
            folder(10, "/Pictures", "Pictures", None, true),
            folder(11, "/Pictures/Drone", "Drone", Some(10), false),
            folder(20, "/Data", "Data", None, true),
            folder(21, "/Data/Trips", "Trips", Some(20), false),
        ];
        let mut photos = vec![
            photo_in_folder("/Pictures/Drone/p.jpg", 11, "/Pictures/Drone"),
            photo_in_folder("/Data/Trips/d.jpg", 21, "/Data/Trips"),
        ];

        let tree_order = folder_stream_order(&folders, crate::sidebar::FolderDisplayMode::Tree);
        let flat_order =
            folder_stream_order(&folders, crate::sidebar::FolderDisplayMode::ImportedOnly);
        assert_eq!(tree_order, flat_order);

        sort_folder_stream(
            &mut photos,
            &folders,
            PhotoSort {
                field: SortField::Name,
                direction: SortDirection::Ascending,
            },
            crate::sidebar::FolderDisplayMode::ImportedOnly,
        );

        assert_eq!(
            photos.iter().map(|photo| photo.folder_id).collect::<Vec<_>>(),
            vec![Some(21), Some(11)]
        );
    }

    #[test]
    fn photo_sort_supports_names_dates_sizes_and_dimensions() {
        let source = vec![
            photo("/photos/z.jpg", Some("2022"), Some(20), None, Some(2)),
            photo(
                "/photos/A.jpg",
                Some("2024"),
                Some(10),
                Some((6000, 4000)),
                Some(3),
            ),
            photo("/photos/m.jpg", None, Some(30), Some((3000, 2000)), Some(1)),
        ];

        let sorted_paths = |field, direction| {
            let mut photos = source.clone();
            sort_photos(&mut photos, PhotoSort { field, direction });
            photos
                .into_iter()
                .map(|photo| photo.path)
                .collect::<Vec<_>>()
        };
        assert_eq!(
            sorted_paths(SortField::Name, SortDirection::Ascending),
            ["/photos/A.jpg", "/photos/m.jpg", "/photos/z.jpg"]
        );
        assert_eq!(
            sorted_paths(SortField::DateTaken, SortDirection::Descending),
            ["/photos/A.jpg", "/photos/z.jpg", "/photos/m.jpg"]
        );
        assert_eq!(
            sorted_paths(SortField::FileSize, SortDirection::Descending),
            ["/photos/m.jpg", "/photos/z.jpg", "/photos/A.jpg"]
        );
        assert_eq!(
            sorted_paths(SortField::Dimensions, SortDirection::Descending),
            ["/photos/A.jpg", "/photos/m.jpg", "/photos/z.jpg"]
        );
        assert_eq!(
            sorted_paths(SortField::DateAdded, SortDirection::Ascending),
            ["/photos/m.jpg", "/photos/z.jpg", "/photos/A.jpg"]
        );
    }
}

#[cfg(test)]
mod network_share_path_regression_tests {
    use super::path_belongs_to_share;

    #[test]
    fn matches_gvfs_photos_under_uri_share() {
        let root = "smb://DietPi.local:445/4TBS/Spar%20Ladies%202025";
        assert!(path_belongs_to_share(root,
            "/run/user/1000/gvfs/smb-share:server=dietpi.local,share=4tbs/Spar Ladies 2025/FB-Spar Womens-ToUpload/p.jpg"));
        assert!(path_belongs_to_share("smb://dietpi.local/4tbp/ImmichLibrary",
            "smb://dietpi.local/4tbp/ImmichLibrary/2025/p.jpg"));
    }

    #[test]
    fn excludes_other_shares_and_prefix_collisions() {
        let root = "smb://dietpi.local/4tbs/series-kids";
        assert!(!path_belongs_to_share(root,
            "/run/user/1000/gvfs/smb-share:server=dietpi.local,share=4tbs/series-kids-old/p.jpg"));
        assert!(!path_belongs_to_share(root,
            "/run/user/1000/gvfs/smb-share:server=other.local,share=4tbs/series-kids/p.jpg"));
        assert!(!path_belongs_to_share(root,
            "/run/user/1000/gvfs/smb-share:server=dietpi.local,share=4tbp/series-kids/p.jpg"));
    }
}
