fn notify_photo_changed(handler: &PhotoChangedHandler, photos: &[PhotoObject], index: usize) {
    let Some(photo) = photos.get(index) else {
        return;
    };
    if let Some(handler) = handler.borrow().as_ref() {
        handler(photo.clone());
    }
}

fn show_photo(
    picture: &gtk::Picture,
    photos: &[PhotoObject],
    index: usize,
    root: &gtk::Overlay,
    zoom: Rc<Cell<f64>>,
    generation: Rc<Cell<u64>>,
    expected_generation: u64,
    decode_cancel: Rc<RefCell<Option<Arc<AtomicBool>>>>,
    picture_viewport: &gtk::ScrolledWindow,
    native_texture: Rc<RefCell<Option<NativeTextureCache>>>,
    display_texture_cache: DisplayTextureCache,
    fit_geometry_fixed: bool,
    cache_hit: bool,
) {
    let Some(photo) = photos.get(index) else {
        return;
    };

    // Decode a display-quality image off the GTK thread. The cached thumbnail
    // is shown only for the initial open. During navigation the previous full
    // image remains until this result is ready, avoiding a low-resolution
    // thumbnail flash between adjacent photos.
    let path = photo.path();
    if let Some(previous) = decode_cancel.borrow_mut().take() {
        previous.store(true, Ordering::Release);
    }
    if cache_hit {

        return;
    }
    let cancelled = Arc::new(AtomicBool::new(false));
    *decode_cancel.borrow_mut() = Some(cancelled.clone());
    let cancelled_for_thread = cancelled.clone();
    let result_slot = ResultSlot::new();
    let result_slot_for_worker = result_slot.clone();
    let decode_path = path.clone();
    crate::source::net_trace(format!("decode_start uri={decode_path}"));
    let decode_started = std::time::Instant::now();
    let rotation = photo.rotation();
    let edit_recipe_text = photo.edit_recipe();
    let edit_recipe = crate::edit::EditRecipe::decode(&edit_recipe_text);
    let (target_width, target_height, _, _, _, _) =
        viewer_decode_target(root, rotation, zoom.get() < 0.0);

    if std::thread::Builder::new()
        .name("lightbox-decode".to_string())
        .spawn(move || {
            if cancelled_for_thread.load(Ordering::Acquire) {
                result_slot_for_worker.send(Err(anyhow::anyhow!("cancelled before decode")));
                return;
            }
            let gate = VIEWER_DECODE_GATE
                .get_or_init(|| DecodeSemaphore::new(MAX_CONCURRENT_VIEWER_DECODES));
            let Some(_permit) = gate.acquire_cancelled(&cancelled_for_thread) else {

                result_slot_for_worker.send(Err(anyhow::anyhow!("cancelled at decode gate")));
                return;
            };

            let result: anyhow::Result<(u32, u32, Vec<u8>)> = (|| {
                let image = crate::thumbnail::decode_for_viewer_with_cancel(
                    &decode_path,
                    target_width,
                    target_height,
                    || cancelled_for_thread.load(Ordering::Acquire),
                )?;
                if cancelled_for_thread.load(Ordering::Acquire) {
                    anyhow::bail!("cancelled");
                }
                let image = rotate_image(image, rotation);
                let image = crate::edit::render::apply_recipe(image, &edit_recipe);

                Ok((image.width(), image.height(), image.into_raw()))
            })();
            result_slot_for_worker.send(result);
        })
        .is_err() {
        result_slot.send(Err(anyhow::anyhow!("could not start lightbox decode thread")));
    }

    let picture = picture.clone();
    let root = root.clone();
    let picture_viewport = picture_viewport.clone();
    let cache_path = path.clone();
    let photo = photo.clone();
    let display_texture_cache_for_result = display_texture_cache.clone();
    glib::MainContext::default().spawn_local(async move {
        let result = ResultSlot::wait(result_slot).await;

        if generation.get() != expected_generation || cancelled.load(Ordering::Acquire) {

            return;
        }

        match result {
            Ok((width, height, pixels)) => {
                crate::source::net_trace(format!(
                    "decode_done uri={cache_path} w={width} h={height} ms={:.1}",
                    decode_started.elapsed().as_secs_f64() * 1000.0
                ));
                let bytes = glib::Bytes::from_owned(pixels);
                let texture = gtk::gdk::MemoryTexture::new(
                    width as i32,
                    height as i32,
                    gtk::gdk::MemoryFormat::R8g8b8a8,
                    &bytes,
                    width as usize * 4,
                );

                // Never overwrite PhotoObject's source dimensions with the
                // dimensions of a display-sized viewer decode. The original
                // dimensions are what 1:1 mode needs to request native pixels.
                if zoom.get() < 0.0 {
                    *native_texture.borrow_mut() = Some(NativeTextureCache {
                        path: cache_path.clone(),
                        rotation,
                        edit_recipe: edit_recipe_text.clone(),
                        texture: texture.clone(),
                    });
                }

                picture.set_paintable(Some(&texture));
                if zoom.get() >= 0.0 {
                    if !fit_geometry_fixed {
                        fit_picture(
                            &picture,
                            std::slice::from_ref(&photo),
                            0,
                            root.width(),
                            root.height(),
                            zoom.get(),
                        );
                    }
                    display_texture_cache_insert(
                        &display_texture_cache_for_result,
                        cache_path.clone(),
                        rotation,
                        edit_recipe_text.clone(),
                        target_width,
                        target_height,
                        texture.clone(),
                    );
                }
                if zoom.get() < 0.0 {
                    picture.queue_resize();
                    picture_viewport.queue_resize();
                    center_viewport_soon(&picture_viewport);
                }

            }
            Err(error) => {
                // A failed decode must not leave the previous photo visible.
                // This is especially important when navigating from a valid
                // image to a corrupt source: retaining the old paintable makes
                // the viewer appear to open the wrong photo.
                picture.set_paintable(gtk::gdk::Paintable::NONE);
                picture.set_filename(Option::<&str>::None);
                picture.set_size_request(1, 1);

                // An offline network share reads as a failed READ (not a
                // corrupt file). Tell the user why the photo did not open
                // and how to fix it - rate-limited so keyboard navigation
                // through an offline folder cannot spam dialogs.
                let message = error.to_string();
                let network_read_failure = message.contains("could not read")
                    && (message.contains("smb://")
                        || message.contains("nfs://")
                        || message.contains("/run/user/"));
                if network_read_failure && should_show_unavailable_notice() {
                    crate::source::net_trace(format!(
                        "lightbox_unavailable_notice uri={cache_path}"
                    ));
                    use libadwaita as adw;
                    use libadwaita::prelude::*;
                    let dialog = adw::AlertDialog::builder()
                        .heading("Original unavailable")
                        .body("This photo is on a network share that is currently offline. Use \"Retry Connection\" on the share in the sidebar, then open the photo again.")
                        .build();
                    dialog.add_response("ok", "OK");
                    dialog.present(Some(&root));
                }
            }
        }
    });

}

/// Rate limit for the offline-original notice (one per 10 s across all
/// lightbox decodes).
fn should_show_unavailable_notice() -> bool {
    static LAST_NOTICE: std::sync::OnceLock<Mutex<std::time::Instant>> = std::sync::OnceLock::new();
    let last = LAST_NOTICE.get_or_init(|| Mutex::new(std::time::Instant::now() - std::time::Duration::from_secs(60)));
    let mut last = match last.lock() {
        Ok(last) => last,
        Err(poisoned) => poisoned.into_inner(),
    };
    if last.elapsed() >= std::time::Duration::from_secs(10) {
        *last = std::time::Instant::now();
        true
    } else {
        false
    }
}

fn display_texture_cache_lookup(
    cache: &DisplayTextureCache,
    path: &str,
    rotation: i32,
    edit_recipe: &str,
    target_width: u32,
    target_height: u32,
) -> Option<gtk::gdk::MemoryTexture> {
    let mut cache = cache.borrow_mut();
    let position = cache.iter().position(|entry| {
        entry.path == path
            && entry.rotation == rotation
            && entry.edit_recipe == edit_recipe
            && entry.target_width == target_width
            && entry.target_height == target_height
    })?;
    let entry = cache.remove(position)?;
    let texture = entry.texture.clone();
    cache.push_front(entry);
    Some(texture)
}

fn display_texture_cache_insert(
    cache: &DisplayTextureCache,
    path: String,
    rotation: i32,
    edit_recipe: String,
    target_width: u32,
    target_height: u32,
    texture: gtk::gdk::MemoryTexture,
) {
    // RGBA8 footprint of the texture. Used by the byte budget so a large or
    // zoomed viewport cannot cache an unbounded amount of pixel memory.
    let bytes = (texture.width().max(0) as usize)
        .saturating_mul(texture.height().max(0) as usize)
        .saturating_mul(4);
    let mut cache = cache.borrow_mut();
    cache.retain(|entry| {
        !(entry.path == path
            && entry.rotation == rotation
            && entry.edit_recipe == edit_recipe
            && entry.target_width == target_width
            && entry.target_height == target_height)
    });
    cache.push_front(DisplayTextureCacheEntry {
        path,
        rotation,
        edit_recipe,
        target_width,
        target_height,
        texture,
        bytes,
    });
    // Evict least-recently-used entries past either the count or the byte
    // budget. Always keep at least one entry so a single oversized texture can
    // still be shown without the cache immediately dropping everything.
    let mut total: usize = cache.iter().map(|entry| entry.bytes).sum();
    while cache.len() > DISPLAY_TEXTURE_CACHE_CAPACITY
        || (total > DISPLAY_TEXTURE_CACHE_BYTE_BUDGET && cache.len() > 1)
    {
        let Some(removed) = cache.pop_back() else {
            break;
        };
        total = total.saturating_sub(removed.bytes);
    }
}

thread_local! {
    // Only one lightbox exists, so the pending prefetch timer and cancel token
    // live in thread-local state rather than on every navigation closure.
    static PREFETCH_SOURCE: RefCell<Option<glib::SourceId>> = const { RefCell::new(None) };
    static PREFETCH_CANCEL: RefCell<Option<Arc<AtomicBool>>> = const { RefCell::new(None) };
}

/// Cancel the pending prefetch timer and any in-flight prefetch decode.
/// Called on every navigation (so a stale prefetch never competes with the
/// photo the user actually moved to) and when the lightbox closes.
fn cancel_lightbox_prefetch() {
    PREFETCH_SOURCE.with(|slot| {
        if let Some(source) = slot.borrow_mut().take() {
            source.remove();
        }
    });
    PREFETCH_CANCEL.with(|slot| {
        if let Some(cancel) = slot.borrow_mut().take() {
            cancel.store(true, Ordering::Release);
        }
    });
}

/// After the user settles on a photo, warm the display-texture cache for the
/// neighbor in the direction they are moving. Delayed slightly so rapid
/// stepping does not queue a decode per keypress, and cancelled on the next
/// navigation or on close.
fn schedule_lightbox_prefetch(
    photos: Rc<RefCell<Vec<PhotoObject>>>,
    current: usize,
    direction: i32,
    root: gtk::Overlay,
    zoom: Rc<Cell<f64>>,
    cache: DisplayTextureCache,
    generation: Rc<Cell<u64>>,
) {
    cancel_lightbox_prefetch();
    if direction == 0 || !root.is_visible() {
        return;
    }
    let expected_generation = generation.get();
    let source = glib::timeout_add_local(Duration::from_millis(250), move || {
        PREFETCH_SOURCE.with(|slot| {
            slot.borrow_mut().take();
        });
        if !root.is_visible() || generation.get() != expected_generation {
            return glib::ControlFlow::Break;
        }
        let len = photos.borrow().len();
        let target = if direction < 0 {
            current.checked_sub(1)
        } else {
            (current + 1 < len).then_some(current + 1)
        };
        let Some(target) = target else {
            return glib::ControlFlow::Break;
        };
        let cancel = Arc::new(AtomicBool::new(false));
        PREFETCH_CANCEL.with(|slot| {
            slot.borrow_mut().replace(cancel.clone());
        });
        prefetch_display_texture(
            &photos.borrow(),
            target,
            &root,
            zoom.get(),
            cache.clone(),
            cancel,
        );
        glib::ControlFlow::Break
    });
    PREFETCH_SOURCE.with(|slot| {
        slot.borrow_mut().replace(source);
    });
}

/// Decode a neighbor photo into the display cache without touching the visible
/// picture. Uses the shared decode gate so a burst of prefetches cannot spawn
/// unbounded full-resolution RAW decodes, and bails out as soon as its cancel
/// token is set.
fn prefetch_display_texture(
    photos: &[PhotoObject],
    index: usize,
    root: &gtk::Overlay,
    zoom: f64,
    cache: DisplayTextureCache,
    cancel: Arc<AtomicBool>,
) {
    let Some(photo) = photos.get(index) else {
        return;
    };
    if zoom < 0.0 {
        return;
    }
    let (target_width, target_height, _, _, _, _) =
        viewer_decode_target(root, photo.rotation(), false);
    let path = photo.path();
    if display_texture_cache_lookup(
        &cache,
        &path,
        photo.rotation(),
        &photo.edit_recipe(),
        target_width,
        target_height,
    )
    .is_some()
    {
        return;
    }

    let rotation = photo.rotation();
    let edit_recipe_text = photo.edit_recipe();
    let edit_recipe = crate::edit::EditRecipe::decode(&edit_recipe_text);
    let decode_path = path.clone();
    let cache_path = path.clone();
    let cache_for_result = cache.clone();
    let result_slot: Arc<ResultSlot<anyhow::Result<(u32, u32, Vec<u8>)>>> = ResultSlot::new();
    let result_slot_for_worker = result_slot.clone();
    let cancel_for_thread = cancel.clone();
    if std::thread::Builder::new()
        .name("lightbox-prefetch".to_string())
        .spawn(move || {
            let aborted = || anyhow::anyhow!("cancelled");
            if cancel_for_thread.load(Ordering::Acquire) {
                result_slot_for_worker.send(Err(aborted()));
                return;
            }
            let gate = VIEWER_DECODE_GATE
                .get_or_init(|| DecodeSemaphore::new(MAX_CONCURRENT_VIEWER_DECODES));
            let Some(_permit) = gate.acquire_cancelled(&cancel_for_thread) else {
                result_slot_for_worker.send(Err(aborted()));
                return;
            };
            let result = (|| -> anyhow::Result<(u32, u32, Vec<u8>)> {
                let image = crate::thumbnail::decode_for_viewer_with_cancel(
                    &decode_path,
                    target_width,
                    target_height,
                    || cancel_for_thread.load(Ordering::Acquire),
                )?;
                if cancel_for_thread.load(Ordering::Acquire) {
                    anyhow::bail!("cancelled");
                }
                let image = rotate_image(image, rotation);
                let image = crate::edit::render::apply_recipe(image, &edit_recipe);
                Ok((image.width(), image.height(), image.into_raw()))
            })();
            result_slot_for_worker.send(result);
        })
        .is_err()
    {
        return;
    }

    glib::MainContext::default().spawn_local(async move {
        let result = ResultSlot::wait(result_slot).await;
        if cancel.load(Ordering::Acquire) {
            return;
        }
        let Ok((width, height, pixels)) = result else {
            return;
        };
        let bytes = glib::Bytes::from_owned(pixels);
        let texture = gtk::gdk::MemoryTexture::new(
            width as i32,
            height as i32,
            gtk::gdk::MemoryFormat::R8g8b8a8,
            &bytes,
            width as usize * 4,
        );
        display_texture_cache_insert(
            &cache_for_result,
            cache_path,
            rotation,
            edit_recipe_text,
            target_width,
            target_height,
            texture,
        );

    });
}

fn prepare_navigation_photo(
    picture: &gtk::Picture,
    photo: Option<&PhotoObject>,
    root: &gtk::Overlay,
    zoom: f64,
    display_cache: &DisplayTextureCache,
) -> (bool, bool) {
    let Some(photo) = photo else {
        return (false, false);
    };

    if zoom < 0.0 {
        return (false, false);
    }

    let (target_width, target_height, _, _, _, _) =
        viewer_decode_target(root, photo.rotation(), false);
    let path = photo.path();
    if let Some(texture) = display_texture_cache_lookup(
        display_cache,
        &path,
        photo.rotation(),
        &photo.edit_recipe(),
        target_width,
        target_height,
    ) {
        set_fit_geometry_from_intrinsic(
            picture,
            photo,
            root,
            zoom,
            texture.width(),
            texture.height(),
        );
        picture.set_paintable(Some(&texture));

        return (true, true);
    }

    // Nikon RAW/NEF cached thumbnails can have a different presentation
    // path/aspect from the embedded display preview. Leave the previous full
    // image in place for uncached RAW navigation so it cannot flash a second
    // image or trigger a transient black-bar allocation.
    if crate::image_format::uses(&path, crate::image_format::DecoderKind::Raw) {

        return (false, false);
    }

    let Some(thumbnail) = photo
        .cached_thumbnail_path()
        .filter(|thumbnail| std::path::Path::new(thumbnail).is_file())
    else {
        return (false, false);
    };
    let Ok((mut width, mut height)) = image::image_dimensions(&thumbnail) else {
        return (false, false);
    };
    if matches!(photo.rotation().rem_euclid(360), 90 | 270) {
        std::mem::swap(&mut width, &mut height);
    }

    set_fit_geometry_from_intrinsic(
        picture,
        photo,
        root,
        zoom,
        width as i32,
        height as i32,
    );
    if photo.rotation().rem_euclid(360) == 0 {
        picture.set_filename(Some(thumbnail));
    } else if let Some(rotated) = crate::photo_texture::edited_thumbnail(&thumbnail, photo.rotation(), &photo.edit_recipe())
    {
        picture.set_paintable(Some(&rotated));
    } else {
        return (false, false);
    }

    (true, false)
}

fn set_fit_geometry_from_intrinsic(
    picture: &gtk::Picture,
    photo: &PhotoObject,
    root: &gtk::Overlay,
    zoom: f64,
    intrinsic_width: i32,
    intrinsic_height: i32,
) {
    let (native_width, native_height) = presentation_native_dimensions(photo);
    let (width, height) = fitted_picture_dimensions(
        native_width,
        native_height,
        intrinsic_width,
        intrinsic_height,
        root.width(),
        root.height(),
        zoom,
    );
    picture.set_size_request(width, height);
}

fn presentation_native_dimensions(photo: &PhotoObject) -> (i64, i64) {
    let (mut width, mut height) = (photo.width().max(1) as u32, photo.height().max(1) as u32);
    if matches!(photo.rotation().rem_euclid(360), 90 | 270) {
        std::mem::swap(&mut width, &mut height);
    }
    let recipe = crate::edit::EditRecipe::decode(&photo.edit_recipe());
    let (width, height) = crate::edit::render::estimated_output_dimensions(width, height, &recipe);
    (i64::from(width), i64::from(height))
}

fn reset_viewport(viewport: &gtk::ScrolledWindow) {
    let horizontal = viewport.hadjustment();
    let vertical = viewport.vadjustment();
    horizontal.set_value(horizontal.lower());
    vertical.set_value(vertical.lower());
}

fn center_viewport_soon(viewport: &gtk::ScrolledWindow) {
    let viewport = viewport.clone();

    // Wait until GTK has applied the native-size child allocation and the
    // ScrolledWindow adjustments expose their real upper/page_size values.
    // A plain idle callback can run too early, leaving the 1:1 view at 0,0.
    glib::timeout_add_local_once(Duration::from_millis(16), move || {
        let horizontal = viewport.hadjustment();
        let vertical = viewport.vadjustment();

        let max_h = (horizontal.upper() - horizontal.page_size()).max(horizontal.lower());
        let max_v = (vertical.upper() - vertical.page_size()).max(vertical.lower());

        let centered_h = horizontal.lower() + (max_h - horizontal.lower()) / 2.0;
        let centered_v = vertical.lower() + (max_v - vertical.lower()) / 2.0;

        horizontal.set_value(centered_h);
        vertical.set_value(centered_v);

    });
}

fn show_cached_preview(picture: &gtk::Picture, photo: &PhotoObject) {
    if let Some(thumbnail) = photo
        .cached_thumbnail_path()
        .filter(|path| std::path::Path::new(path).is_file())
    {
        if let Some(rotated) = crate::photo_texture::edited_thumbnail(&thumbnail, photo.rotation(), &photo.edit_recipe())
        {
            picture.set_paintable(Some(&rotated));
        } else {
            picture.set_filename(Some(thumbnail));
        }

    } else {
        // `Picture` can retain its previous paintable across lightbox opens.
        // Clear it before decoding a photo with no usable cached thumbnail.
        picture.set_paintable(gtk::gdk::Paintable::NONE);
        picture.set_filename(Option::<&str>::None);
    }
}

fn viewer_decode_target(
    root: &gtk::Overlay,
    rotation: i32,
    one_to_one: bool,
) -> (u32, u32, i32, i32, i32, bool) {
    let allocated_width = root.width() - VIEWER_PADDING;
    let allocated_height = root.height() - VIEWER_PADDING;
    let fallback = allocated_width <= 0 || allocated_height <= 0;
    let (logical_width, logical_height) = if fallback {
        // A hidden overlay normally retains its window allocation. This only
        // applies on the very first frame before GTK has allocated the window.
        (1024, 768)
    } else {
        (allocated_width, allocated_height)
    };
    let scale_factor = root.scale_factor().max(1);
    // RAW catalog dimensions are frequently absent and can describe the
    // sensor rather than its embedded display preview. Use an unbounded 1:1
    // request and let decode_for_viewer clamp it to the actual source it
    // discovers. Falling back to the viewport made 1:1 indistinguishable
    // from fit-to-window for DNG and many NEF files.
    let mut target_width = if one_to_one {
        u32::MAX
    } else {
        (logical_width as u32).saturating_mul(scale_factor as u32)
    };
    let mut target_height = if one_to_one {
        u32::MAX
    } else {
        (logical_height as u32).saturating_mul(scale_factor as u32)
    };
    // decode_for_viewer applies EXIF orientation; user rotation happens in
    // this module afterward, so swap its input bounds for a quarter-turn.
    if matches!(rotation.rem_euclid(360), 90 | 270) {
        std::mem::swap(&mut target_width, &mut target_height);
    }
    (
        target_width.max(1),
        target_height.max(1),
        logical_width,
        logical_height,
        scale_factor,
        fallback,
    )
}

fn rotate_image(image: image::RgbaImage, rotation: i32) -> image::RgbaImage {
    match rotation.rem_euclid(360) {
        90 => image::imageops::rotate90(&image),
        180 => image::imageops::rotate180(&image),
        270 => image::imageops::rotate270(&image),
        _ => image,
    }
}

fn fit_picture(
    picture: &gtk::Picture,
    photos: &[PhotoObject],
    index: usize,
    viewport_width: i32,
    viewport_height: i32,
    zoom: f64,
) {
    let Some(photo) = photos.get(index) else {
        return;
    };

    if viewport_width <= 0 || viewport_height <= 0 {
        return;
    }

    let paintable = picture.paintable();
    let intrinsic_width = paintable
        .as_ref()
        .map(gtk::gdk::Paintable::intrinsic_width)
        .unwrap_or(0);
    let intrinsic_height = paintable
        .as_ref()
        .map(gtk::gdk::Paintable::intrinsic_height)
        .unwrap_or(0);
    let (native_width, native_height) = presentation_native_dimensions(photo);
    let (fitted_width, fitted_height) = fitted_picture_dimensions(
        native_width,
        native_height,
        intrinsic_width,
        intrinsic_height,
        viewport_width,
        viewport_height,
        zoom,
    );

    picture.set_size_request(fitted_width, fitted_height);

}

fn fitted_picture_dimensions(
    native_width: i64,
    native_height: i64,
    intrinsic_width: i32,
    intrinsic_height: i32,
    viewport_width: i32,
    viewport_height: i32,
    zoom: f64,
) -> (i32, i32) {
    let intrinsic_valid = intrinsic_width > 0 && intrinsic_height > 0;
    let native_valid = native_width > 0 && native_height > 0;

    // At 1:1, use the pixels actually present in the decoded texture. A RAW
    // embedded preview may differ from the sensor dimensions in the catalog.
    let (mut source_width, mut source_height) = if zoom < 0.0 && intrinsic_valid {
        (f64::from(intrinsic_width), f64::from(intrinsic_height))
    } else if native_valid {
        (native_width as f64, native_height as f64)
    } else if intrinsic_valid {
        (f64::from(intrinsic_width), f64::from(intrinsic_height))
    } else {
        (1.0, 1.0)
    };

    // Cached thumbnails are already EXIF-oriented, while database dimensions
    // generally describe the encoded source. Use the thumbnail only to detect
    // an axis swap; keep the native dimensions as the scaling limit. This
    // presents a large photo's thumbnail at its final fitted size without
    // treating a genuinely small source as a large image.
    if native_valid
        && intrinsic_valid
        && (source_width > source_height) != (intrinsic_width > intrinsic_height)
    {
        std::mem::swap(&mut source_width, &mut source_height);
    }

    let available_width = (viewport_width - VIEWER_PADDING).max(1) as f64;
    let available_height = (viewport_height - VIEWER_PADDING).max(1) as f64;
    let fit_scale = (available_width / source_width).min(available_height / source_height);
    // Known native dimensions remain the hard cap, so small source images are
    // never enlarged. If metadata is unavailable (common for RAW), this is a
    // cached opening preview rather than the decoded source; present it at the
    // viewer's fitted size while the correctly sized full decode is pending.
    let fit_scale = if native_valid {
        fit_scale.min(1.0)
    } else {
        fit_scale
    };
    let scale = if zoom < 0.0 {
        1.0
    } else if zoom == 0.0 {
        fit_scale
    } else {
        fit_scale * zoom
    };

    (
        (source_width * scale).round().max(1.0) as i32,
        (source_height * scale).round().max(1.0) as i32,
    )
}
